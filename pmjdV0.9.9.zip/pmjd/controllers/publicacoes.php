<?php

class Publicacoes extends Controller {

   function __construct() {
      parent::__construct();
   }

   public function index() {
      $this->lista_publicacoes("2012");
      $this->lista_publicacoes("2011");
      $this->lista_publicacoes("2010");
      $this->lista_publicacoes("outros");
      $this->view->render("publicacoes/index");
   }

   public function concursos() {
      $this->view->render("publicacoes/concursos");
   }

   public function documentacao() {
      $this->view->render("publicacoes/documentacao");
   }

   public function transparencia() {
      $this->view->render("publicacoes/transparencia");
   }
   
   private function trataTxt($var) {

      $var = strtolower($var);
      
      $var = ereg_replace("[áàâãª]","a",$var);  
      $var = ereg_replace("[éèê]","e",$var); 
      $var = ereg_replace("[óòôõº]","o",$var);  
      $var = ereg_replace("[úùû]","u",$var); 
      $var = str_replace("ç","c",$var);
      
      return $var;
   }

   public function lista_publicacoes($ano){
      $diretorio = getcwd();
      
      $pasta_ano="/publicacoes_pdf/".$ano;
      $diretorio = $diretorio.$pasta_ano;
      
      $publicacao = opendir($diretorio);
      
      while($nome_arquivo = readdir($publicacao)){
         $itens[] = $nome_arquivo;
      }
      
      sort($itens);
      foreach($itens as $listar){
         if($listar != "." && $listar!=".."){
            $arquivos[] = $listar;       
         }
      }
      if(!empty($arquivos)){
         switch($ano){
            case '2012':
               $this->view->ano2012 = $arquivos;
               break;
            case '2011':
               $this->view->ano2011 = $arquivos;
               break;
            case '2010':
               $this->view->ano2010 = $arquivos;
               break;
            case 'outros':
               $this->view->ano = $arquivos;
               break;         
         }
      }
   }

   public function publicacoes_pdf($arquivo){
      $this->render("../publicacoes_pdf/".$arquivo);
   }
}

?>