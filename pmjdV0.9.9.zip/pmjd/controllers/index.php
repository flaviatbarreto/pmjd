<?php

class Index extends Controller {

   function __construct() {
      parent::__construct();
      $this->view->js = array("index/js/jquery.js", "index/js/jquery-1.7.2.min.js");
      //$this->view->css = array("index/css/s3Slider.css");
   }

   public function index() {
      $this->view->render("index/index");
   }
   
   public function teste() {
      $this->view->render("index/teste");
   }
   

}
?>
