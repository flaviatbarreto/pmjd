<?php

class Obras extends Controller{
	function __construct(){
		parent::__construct();
		/*$this->view->js = array("obras/js/jquery.fancybox.js");
        $this->view->css = array("obras/css/jquery.fancybox.css");*/
	}
	
	public function index(){
		$this->view->render("obras/index");
	}
}

?>