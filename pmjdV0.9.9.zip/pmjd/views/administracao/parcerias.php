﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Parcerias</p>
	</div>
</div>

<div id="conteudo_interno">
<div id='parceria_texto'>
	<p>Esse espa&ccedil;o cont&eacute;m os nossos parceiros e aqueles que nos apoiam nos nossos projetos:</p>
</div>
<div id='parceria_linha'>
	<div id='parceria_1'></div>
	<div id='parceria_2'></div>
	<div id='parceria_3'></div>
</div>
</div>
