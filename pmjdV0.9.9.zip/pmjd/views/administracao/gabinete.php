﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Gabinete do Prefeito</p>
	</div>
</div>

<div id="conteudo_interno">
<div id='prefeito'>
	<div id='prefeito_sub'>
		<p>Sobre o Prefeito:</p>
	</div>
	<div id='foto'></div>
	<div id='prefeito_texto'>
		<p>
			Aqui coloca a biografia sobre o texto pra dizer a sua trajetoria
			e outras coisas cabiveis nesse lugar sobre o prefeito.
		</p>
	</div>
</div>

<div id='sublinha_centro'></div>

<div id='prefeito'>
	<div id='prefeito_sub'>
		<p>Sobre o Vice-Prefeito:</p>
	</div>
	<div id='foto'></div>
	<div id='prefeito_texto'>
		<p>
			Aqui coloca a biografia sobre o texto pra dizer a sua trajetoria
			e outras coisas cabiveis nesse lugar sobre o vice-prefeito.
		</p>
	</div>
</div>
</div>