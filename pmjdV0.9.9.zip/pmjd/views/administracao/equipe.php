﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Equipe de Governo</p>
	</div>
</div>

<div id="conteudo_interno">
<div id='equipe'>
	<div id='equipe_sub'>
		<p>Secret&aacute;rio de Governo</p>
	</div>
	<div id='equipe_foto'></div>	
	<div id='equipe_texto'>
		<p>Nome: Lucas Vasconcelos</p>
		<p>Telefone: (74) 9985-4599</p>
	</div>

</div>

<div id='equipe'>
	<div id='equipe_sub'>
		<p>Secret&aacute;rio de Governo</p>
	</div>
	<div id='equipe_foto'></div>	
	<div id='equipe_texto'>
		<p>Nome: Lucas Vasconcelos</p>
		<p>Telefone: (74) 9985-4599</p>
	</div>

</div>

<div id='equipe'>
	<div id='equipe_sub'>
		<p>Secret&aacute;rio de Governo</p>
	</div>
	<div id='equipe_foto'></div>	
	<div id='equipe_texto'>
		<p>Nome: Lucas Vasconcelos</p>
		<p>Telefone: (74) 9985-4599</p>
	</div>

</div>
</div>