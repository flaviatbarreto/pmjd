﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Secretarias</p>
	</div>
</div>

<div id="conteudo_interno">
<div id='secretaria'>
	<div id='secretaria_sub'>
		<p>Secretaria de Educa&ccedil;&atilde;o:</p>
	</div>
	<div id='secretaria_texto'>
		<p>
			Tudo sobre a secretaria que est&aacute; sendo descrita nesse espa&ccedil;o.
		</p>
	</div>
</div>

<div id='secretaria'>
	<div id='secretaria_sub'>
		<p>Secretaria de Transportes:</p>
	</div>
	<div id='secretaria_texto'>
		<p>
			Tudo sobre a secretaria que est&aacute; sendo descrita nesse espa&ccedil;o.
		</p>
	</div>
</div>
</div>