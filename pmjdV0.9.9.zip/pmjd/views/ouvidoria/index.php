﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Ouvidoria</p>
	</div>
</div>

<div id='ouvidoria_espaco'>
	<div id='ouvidoria_icone'></div>
	<div id='ouvidoria_texto'>
		<p>Aqui voc&ecirc; pode nos enviar as suas d&uacute;vidas, sugest&otilde;es e cr&iacute;ticas. Gostar&iacute;amos de ouvir
		a sua opini&atilde;o.</p>
	</div>
	<div id='formulario_ouvidoria'>
		<p>Nome:</p>
		<input type='text' name='campo_nome' id='formulario_nome' ></input>
		<p>E-mail:</p>
		<input type='text' name='campo_email' id='formulario_nome'></input>	
		<input type='text' name='campo_texto' id='formulario_texto'></input>
		<a href="#">
			<div id='ouvidoria_botao_enviar'>
				<p>Enviar</p>
			</div>
		</a>
	</div>
</div>

<div id='fale_conosco'></div>

<div id='ouvidoria_espaco'>
	<div id='ouvidoria_cidade'></div>
	<div id='ouvidoria_texto'>
		<p>Diga para n&oacute;s como est&aacute; a nossa cidade! Esse espa&ccedil;o &eacute; reservado para voc&ecirc; fazer cr&icirc;ticas, 
		elogios,  e problemas encontrados na nossa cidade. Ajude-nos! </p>
	</div>

	<div id='formulario_ouvidoria'>
		<p>Nome:</p>
		<input type='text' name='campo_nome' id='formulario_nome'></input>
		<p>E-mail:</p>
		<input type='text' name='campo_email' id='formulario_nome'></input>		
		<p>Endereço do local:</p>
		<input type='text' name='campo_email' id='formulario_nome'></input>
		<input type='text' name='campo_texto' id='formulario_texto'></input>		
		<div id='ouvidoria_botao_enviar'>
			<p>Enviar</p>
		</div>
		
	</div>
</div>
