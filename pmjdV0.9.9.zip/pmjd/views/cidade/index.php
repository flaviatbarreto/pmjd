﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>A Cidade</p>
	</div>
</div>

<div id="conteudo_interno">
<div id='cidade'>
	<div id='cidade_intro'>
		<div id='cidade_foto'></div>
		<div id='cidade_texto'>
		Situada a 445 km da capital e a 25 km de Irec&ccedil;. Populacao estimada em 24 mil habitantes. Emancipada em 5 de setembro de 1985.
		</div>
		<div id='cidade_conheca_mais'>Conhe&ccedil;a mais sobre a nossa cidade:</div>
		<div id='cidade_sublinha'></div>
	</div>
	
	<div id='cidade_subtitulo'>
		<div id='historia_icone'></div>
	</div>
	
	<div id='cidade_subtitulo'>
		<div id='localizacao_icone'></div>
	</div>
	
	<div id='cidade_subtitulo'>
		<div id='economia_icone'></div>
	</div>
</div>
</div>