﻿This is for logged in only.

<form id='form' method='post' action='<?php echo URL?>/dashboard/xhrInsert'>
	<input type='text' name='text' />
	<input type='submit' />
</form>

<div id='listInserts'>

</div>