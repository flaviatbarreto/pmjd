﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Publicações</p>
	</div>
</div>

<div id="publicacao_frase"></div>
<div id='publicacoes'>
	<div class="titulo_publicacoes"><div id="publicacao_ano_2012"></div></div>
	<?php
		foreach($this->ano2012 as $listar){
				print "<div id='publicacao'><a target='_blank' href='publicacoes_pdf/2012/$listar'>";		   
				print "<div id='publicacao_data'></div>";
				print "<div id='publicacao_linha'></div>";
				print "<div id='publicacao_texto'>";
				print "<div id='publicacao_texto_tit'>$listar</div><br>";
				print "<div id='publicacao_linha_abaixo'></div>";
				print "</a></div></div>";
		}
	?>
	<div class="titulo_publicacoes"><div id="publicacao_ano_2011"></div></div>
	<?php
		foreach($this->ano2011 as $listar){
				print "<div id='publicacao'><a target='_blank' href='publicacoes_pdf/2011/$listar'>";		   
				print "<div id='publicacao_data'></div>";
				print "<div id='publicacao_linha'></div>";
				print "<div id='publicacao_texto'>";
				print "<div id='publicacao_texto_tit'>$listar</div><br>";
				print "<div id='publicacao_linha_abaixo'></div>";
				print "</a></div></div>";
		}
	?>
	<div class="titulo_publicacoes"><div id="publicacao_ano_2010"></div></div>
	<?php	
		foreach($this->ano2010 as $listar){
				print "<div id='publicacao'><a target='_blank' href='publicacoes_pdf/2010/$listar'>";		   
				print "<div id='publicacao_data'></div>";
				print "<div id='publicacao_linha'></div>";
				print "<div id='publicacao_texto'>";
				print "<div id='publicacao_texto_tit'>$listar</div><br>";
				print "<div id='publicacao_linha_abaixo'></div>";
				print "</a></div></div>";
		}
	?>
	<div class="titulo_publicacoes"><div id="publicacao_ano_outro"></div></div>
	<?php
		foreach($this->ano as $listar){
				print "<div id='publicacao'><a target='_blank' href='publicacoes_pdf/outros/$listar'>";		   
				print "<div id='publicacao_data'></div>";
				print "<div id='publicacao_linha'></div>";
				print "<div id='publicacao_texto'>";
				print "<div id='publicacao_texto_tit'>$listar</div><br>";
				print "<div id='publicacao_linha_abaixo'></div>";
				print "</a></div></div>";
		}
	?>
</div>
