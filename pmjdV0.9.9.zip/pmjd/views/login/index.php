﻿<hr />

<h2>Login</h2>
<table>
	<form method='post' action='login/run'>
	<tr>
		<td><label for='user'>Username: </label></td>
		<td><input type='text' name='user' id='user' /></td>
	</tr>
	<tr>
		<td><label for='pass'>Password: </label></td>
		<td><input type='password' name='pass' id='pass' /></td>
	</tr>
	<tr>
		<td><input type='submit' value='Login' /></td>
	</tr>
</table>
</form>