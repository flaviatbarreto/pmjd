﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Notícias</p>
	</div>
</div>

<div id='conteudo_interno'>
<div id='noticia_principal'>
	<div id='foto_principal'></div>
	<div id='texto_principal'>
		<p>Grupo da 3° idade do Centro de Referência de Assistência Social</p>					
		<div id='texto_principal_sub'>
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce nunc augue, congue vel dapibus sed, feugiat posuere ligula. Suspendisse pellentesque consectetur risus ut ultrices. Suspendisse massa nulla, porta in porttitor a, porta ut justo. Suspendisse tempus, urna et eleifend semper, tortor risus interdum mauris, quis cursus tortor tortor nec erat. Vivamus sollicitudin dapibus euismod. Maecenas a tellus sed risus tincidunt consectetur. Fusce vel libero vel libero vehicula mollis. Cras eros augue, suscipit nec ullamcorper et, imperdiet a eros. Duis pellentesque vestibulum egestas. Nam blandit pellentesque feugiat...
		</div>
	</div>
	<a href="">Continue Lendo...</a>
</div>

<div id='quadro_noticias_secundarias'>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor1.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor2.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>	
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor3.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>	
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor4.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor5.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor6.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>
	<div id='linha_noticia_secundaria'></div>
	<a href="#">		
		<div id='noticia_secundaria'>
			<div id='foto_secundaria'><img src="<?php echo URL?>css/images/noticia_menor.jpg" /></div>
			<div id='titulo_secundario'>Titulo da not&iacute;cia 2</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
		</div>
	</a>	
</div>
