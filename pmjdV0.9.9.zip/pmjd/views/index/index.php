<div id='news'>
  <div id='barra_home'> 
    <div id='barra_menor'></div>
    <div id='barra_maior'></div>
    <p>Not&iacute;cias</p>
  </div>

  <div id="jslidernews2" class="lof-slidecontent" style="width:740px; height:300px;">
  	<div class="preload"><div></div></div>
              
      <div  class="button-previous">Previous</div>
        <div class="main-slider-content" style="width:740px; height:300px;">
                  <ul class="sliders-wrap-inner">
                      <li>
                        <img src="<?php echo URL?>/css/images/slide/thumbl_980x340.png" title="Newsflash 2" >
                      </li> 
                     <li>
                        <img src="<?php echo URL?>/css/images/slide/thumbl_980x340_002.png" title="Newsflash 1" >           
                           
                      </li> 
                     <li>
                        <img src="<?php echo URL?>/css/images/slide/thumbl_980x340_003.png" title="Newsflash 3" >            
                          
                      </li> 
                    </ul>  	
              </div>
             	<div class="navigator-content">
                    <div class="navigator-wrapper">
                          <ul class="navigator-wrap-inner">
                            <li>
                                  <div>
                                      <img src="<?php echo URL?>/css/images/slide/791902news3.jpg" />
                                      <h3> Noticia 1 </h3>
                                      <span>20.01.2010</span> - Um Subtitulo
                                  </div>    
                              </li>
                               <li>
                                  <div>
                                      <img src="<?php echo URL?>/css/images/slide/435576news10.jpg" />
                                      <h3> Noticia 2 </h3>
                                      <span>20.01.2010</span> - Um Subtitulo
                                  </div>    
                              </li>
                  
                              <li>
                                  <div>
                                      <img src="<?php echo URL?>/css/images/slide/641906img1.jpg" />
                                      <h3> Noticia 3 </h3>
                                      <span>20.01.2010</span> - Um Subtitulo
                                  </div>     
                              </li>
                          </ul>
                    </div>
               </div>
   </div> 
  </div>

  <div id='acontece'>
    <div id='barra_home'> 
      <div id='barra_menor'></div>
      <div id='barra_maior'></div>
      <p>PMJD Acontece</p>
    </div>

    <div id="acontece_video">
      <iframe width="430" height="315" src="http://www.youtube.com/embed/0qDEfvWetZY?theme=dark&color=white" frameborder="0" allowfullscreen></iframe>
    </div>
	
     <div id="imagens_acontece">
		<div id="galeria_imagens">
			<div id="galeria_imagens_menor">
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto1.jpg" /></div>
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto2.jpg" /></div>
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto3.jpg" /></div>
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto4.jpg" /></div>				
			</div>
			<div class="img_acontece_maior"><img src="<?php echo URL?>css/images/acontece/acontece_foto5.jpg" /></div>
			<p>Galeria 1 - Encontro de Alunos</p>
		</div>		
		<div id="linha_acontece_imagens"></div>
		<div id="galeria_imagens">			
			<div id="galeria_imagens_menor">
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto6.jpg" /></div>
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto3.jpg" /></div>
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto7.jpg" /></div>
				<div class="img_acontece_menor"><img src="<?php echo URL?>css/images/acontece/acontece_foto2.jpg" /></div>
			</div>
			<div class="img_acontece_maior"><img src="<?php echo URL?>css/images/acontece/acontece_foto8.jpg" /></div>
			<p>Galeria 2 - Apresenta&ccedil;&atilde;o da Orquestra</p>
		</div>
     </div>     
      <div id="sublinha_acontece"></div>
     <div id="acontece_sub">
  		<div id="acontece_videos"></div>
  		<div id="acontece_audios"></div>
  		<div id="acontece_fotos"></div>
     </div>
  </div>

  <div id='obras'>
    <div id='barra_home'> 
      <div id='barra_menor'></div>
      <div id='barra_maior'></div>
      <p>A Prefeitura trabalhando - Obras</p>
    </div>

    <div id="wrapper">
      <div class="slider-wrapper theme-default">
          <div id="slider" class="nivoSlider">
              <img src="<?php echo URL?>/css/images/obras/toystory.jpg" data-thumb="images/toystory.jpg" alt="" />
              <img src="<?php echo URL?>/css/images/obras/up.jpg" data-thumb="images/up.jpg" alt="" title="This is an example of a caption" />
              <img src="<?php echo URL?>/css/images/obras/nemo.jpg" data-thumb="images/nemo.jpg" alt="" title="#htmlcaption" />
          </div>
          <div id="htmlcaption" class="nivo-html-caption">
              <strong>This</strong> is an example of a <em>HTML</em> caption with <a href="#">a link</a>. 
          </div>
      </div>
    </div>
  </div>

  <div id='quadrados'>
  	<img src='<?php echo URL?>/css/images/home_newsletter.png' class="quadrado_img" id="quadrado_newsletter"/>	
    <img src='<?php echo URL?>/css/images/home_producao.png' class="quadrado_img" id="quadrado_producao"/>
    <img src='<?php echo URL?>/css/images/home_ouvidoria.png' class="quadrado_img" id="quadrado_ouvidoria"/>
    <img src='<?php echo URL?>/css/images/home_newsletter.png' class="quadrado_img" id="quadrado_newsletter"/>
  </div>

  <div id="plugins">
    <iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fplatform&amp;width=220&amp;height=258&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;border_color&amp;header=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:220px; height:300px;" allowTransparency="true"></iframe>
  </div>
