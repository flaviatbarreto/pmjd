﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Fotos</p>
	</div>
</div>
<div id="conteudo_interno">
</div>