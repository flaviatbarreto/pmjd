﻿<div id='titulo_news'>
	<div id="titulo_news_menor">
		<p>Obras</p>
	</div>
</div>

<div id="conteudo_interno">
	<div id="galeria_titulo">
		<p>Construção do Colégio Municipal</p>
	</div>
	<div id="galeria_descricao"><p>"Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos. Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado. Se popularizou na década de 60, quando a Letraset lançou decalques contendo passagens de Lorem Ipsum, e mais recentemente quando passou a ser integrado a softwares de editoração eletrônica como Aldus PageMaker."</p></div>
	<div id="galeria_fotos">
	  	
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/1.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/acontece_foto1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/acontece_foto1.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/acontece_foto2.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click the X or anywhere outside the image to close">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/acontece_foto3.jpg" alt="Plants: image 4 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/1.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click the X or anywhere outside the image to close">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/1.jpg" alt="Plants: image 4 0f 4 thumb" width="200px" height="200px"/>
		  </a>
    </div>

    <div id="galeria_titulo">
		<p>Construção do Viaduto UltraMega</p>
	</div>
	<div id="galeria_descricao"><p>"Descrição Menor"</p></div>
	<div id="galeria_fotos">
	  	
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/1.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/acontece_foto1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/acontece_foto1.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/acontece_foto2.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click the X or anywhere outside the image to close">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/acontece_foto3.jpg" alt="Plants: image 4 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click on the right side of the image to move forward.">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/1.jpg" alt="Plants: image 1 0f 4 thumb" width="200px" height="200px"/>
		  </a>
		  <a href="<?php echo URL;?>css/images/obras/fotos/1.jpg" rel="lightbox[plants]" title="Click the X or anywhere outside the image to close">
		  	<img src="<?php echo URL;?>css/images/obras/fotos/1.jpg" alt="Plants: image 4 0f 4 thumb" width="200px" height="200px"/>
		  </a>
    </div>
</div>