﻿<?php
	echo "<hr />";
	echo $this->msg;
?>