
<!-- End div content-->
</div>
</div>
</div>
<!-- End div all-->
</div>

<div id="footer">
	<div id="footer_prefeitura">
		<div id="logo_governo">
		</div>
		<div id="nome_prefeitura">
			<p>Prefeitura Municipal de João Dourado</p>
			<div class="endereco_prefeitura">Praça João Dourado, 132, João Dourado - BA, 44920-000</div>
		</div>	
	</div>
	<div id="links">
		<p>Links úteis</p>
		<a href="http://www.brasil.gov.br/">Governo Federal</a>
		<a href="http://www.ba.gov.br/">Governo da Bahia</a>
		<a href="http://www.sac.ba.gov.br/">SAC</a>
	</div>   
</div>
</body>

</html>
