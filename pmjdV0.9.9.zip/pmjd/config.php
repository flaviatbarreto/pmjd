<?php

//constants
define('HASH_KEY','FLAVIAEHMTOLINDA1');

//paths
define('URL','http://localhost/PMJD/');
define('LIBS',URL.'libs/');

//database
define('DB_TYPE','mysql');
define('DB_HOST','localhost');
define('DB_NAME','infojr');
define('DB_USER','root');
define('DB_PASS','');

//tables
define('USER_TABLE','mvc_users');
define('DATA_TABLE','mvc_data');
?>
